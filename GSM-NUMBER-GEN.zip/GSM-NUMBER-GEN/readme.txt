This is a Simple javascript code developed by Habeeb Salami to generate mobile phone number sequentially and randomly,the sequential generator generates numbers based on the initial number entered at the prompt
and generates the quantity of number enterd at the prompt.
the Random Generator generates the number randomly and does not generates the same number twice.
this code is good for marketer who want to generate mobile phone number for their marketing purpose
you can improve these code by creating a verifier, that will help in verify if the number really exist.

You can contact me at < talk2hb1@gmail.com > <phone number: +2348064620491 > if you need  my service as an Open Source consultants(I consult in open source technology like Joomla, WordPress, Drupal),
 Software developer, Webdesigner, WordPress Theme from PSD, WordPress Plugin.
